// Service worker mínimo (M0.6 — Fundação/PWA).
//
// Objetivo único nesta fase: satisfazer o critério de instalabilidade do
// PWA (Android/Chrome exige um service worker com um handler de `fetch`).
//
// Regra de segurança: NUNCA cachear respostas de dados/autenticação. Só o
// "shell" estático da aplicação (JS/CSS/ícones/manifest) é cacheado.
// Rotas de API, Server Actions e qualquer coisa fora de /_next/static e
// /icons passam direto pela rede (network-only).
//
// TODO (fase futura): evoluir para uma estratégia mais completa de cache
// offline do shell da aplicação, se fizer sentido para o produto.

const STATIC_CACHE = "estoque-ficha-static-v1";
const STATIC_PATH_PREFIXES = ["/_next/static/", "/icons/"];

self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  const isStaticAsset = STATIC_PATH_PREFIXES.some((prefix) =>
    url.pathname.startsWith(prefix),
  );

  if (event.request.method !== "GET" || !isStaticAsset) {
    // Network-only: nunca intercepta nem cacheia dados ou autenticação.
    return;
  }

  event.respondWith(
    caches.open(STATIC_CACHE).then(async (cache) => {
      const cached = await cache.match(event.request);
      if (cached) return cached;

      const response = await fetch(event.request);
      if (response.ok) {
        cache.put(event.request, response.clone());
      }
      return response;
    }),
  );
});
