-- M0.5 — Teste de isolamento entre empresas (OBRIGATÓRIO antes da Fase 3).
-- Revisão 3: ampliado para cobrir também a revisão de segurança que
-- removeu a autoassociação em company_users, criou o bootstrap seguro
-- create_company_with_owner(), proibiu autoelevação de role/is_owner e
-- adicionou os triggers de integridade "mesma empresa" entre tabelas
-- relacionadas.
-- Revisão 4: fixtures de ingredients atualizadas (campo package_quantity
-- removido, ver seção 5.2 do FASE1-ARQUITETURA.md) e testes 5.5/6.5
-- adicionados para company_id imutável nas tabelas pai.
-- Revisão 5: 5.5/6.5 reescritos para usar `products` em vez de `ingredients`
-- (isola o trigger de imutabilidade de outros triggers de integridade que
-- também disparariam); adicionados 6.6 (controle: UPDATE sem mudar
-- company_id continua funcionando), 6.7 (mesmo ataque via service_role) e
-- 6.8 (o mesmo ataque em `ingredients`, mostrando as duas camadas de
-- defesa). As funções auxiliares de RLS (is_member_of_company, is_admin_user)
-- e todas as funções de trigger passaram para o schema `private` (não
-- exposto como RPC pelo PostgREST) com search_path='' — não muda o
-- comportamento de nenhum teste abaixo, só a origem do erro nas mensagens
-- (agora aparece "private.nome_da_funcao" no CONTEXT de cada exceção).
--
-- Revisão 6: M0.5 CONCLUÍDO — este script foi executado de ponta a ponta
-- contra o projeto Supabase real (`barcontrol-dev`), não só contra a
-- emulação local, via o MCP connector do Supabase. Todos os resultados
-- bateram com o esperado. Os dados de teste foram removidos do projeto ao
-- final (seção 8). Ver "Revisão de segurança 6" em
-- web/docs/FASE1-ARQUITETURA.md para o achado de segurança real descoberto
-- nesse processo (advisor do Supabase pegou `anon` com EXECUTE indevido em
-- create_company_with_owner(), corrigido na migration 8).
--
-- Este script FOI executado e passou nesta sessão contra um Postgres 16
-- local com uma emulação do schema `auth` do Supabase (auth.users,
-- auth.uid() lendo request.jwt.claims, papéis authenticated/service_role) —
-- não é apenas teoria, incluindo esta revisão 5 (banco de teste recriado do
-- zero, migrations reaplicadas, suíte inteira rodada de novo). Rode-o de
-- novo no seu projeto Supabase real (SQL Editor) para confirmar contra o
-- ambiente de produção de verdade.
--
-- Como funciona: cada bloco simula "ser" um usuário autenticado setando
-- request.jwt.claims localmente na transação, o que faz auth.uid()
-- retornar o UUID escolhido sem precisar de uma requisição HTTP real. Rode
-- os blocos NA ORDEM, um de cada vez — cada um é sua própria transação.
--
-- Critério de aprovação: se qualquer teste marcado "NÃO deve" retornar
-- linhas/sucesso, ou qualquer teste marcado "deve falhar" for bem-sucedido,
-- a Fase 2 NÃO avança — corrija a policy/trigger e rode tudo de novo.

-- =========================================================================
-- 0. Preparação
-- =========================================================================
-- Crie três usuários de teste pela Authentication do Supabase (dashboard ou
-- supabase.auth.signUp) e cole os UUIDs reais no lugar de USER_A_ID,
-- USER_B_ID e USER_C_ID em todo o script. USER_C simula um usuário que
-- será membro de DUAS empresas (não existe hoje um fluxo do app para isso —
-- é adicionado manualmente no passo 5 só para provar que os triggers de
-- integridade protegem mesmo nesse cenário).
--
-- select id, email from auth.users order by created_at desc limit 5;

-- =========================================================================
-- 1. Usuário A: bootstrap da Empresa A via create_company_with_owner()
--    (não é mais um INSERT direto em companies/company_users — isso foi
--    removido de propósito, ver seção 9 do FASE1-ARQUITETURA.md)
-- =========================================================================
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_A_ID", "role": "authenticated"}';

insert into profiles (id, name, email) values ('USER_A_ID', 'Usuário Teste A', 'teste-a@example.com');

select create_company_with_owner('11111111000191', 'Empresa Teste A', 'Bar da A', 'bar', 'somente_eu', 'São Paulo', 'SP');
commit;

-- Anote o id retornado (coluna "id" dentro do registro companies) — vamos
-- chamá-lo de COMPANY_A_ID no restante do script. O mesmo vale para
-- COMPANY_B_ID no passo 2.
select id as company_a_id from companies where cnpj = '11111111000191';

-- Monta o restante da ficha técnica/contagem de A (troque COMPANY_A_ID pelo valor real):
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_A_ID", "role": "authenticated"}';

insert into ingredient_categories (id, company_id, name)
values ('a1c00000-0000-0000-0000-000000000001', 'COMPANY_A_ID', 'Destilados A');

insert into ingredients (id, company_id, category_id, name, purchase_unit, usage_unit, package_content, package_price)
values ('a1000000-0000-0000-0000-000000000001', 'COMPANY_A_ID', 'a1c00000-0000-0000-0000-000000000001', 'Gin Empresa A', 'garrafa', 'ml', 750, 109.90);

insert into products (id, company_id, name, sale_price)
values ('a2000000-0000-0000-0000-000000000001', 'COMPANY_A_ID', 'Gin Tônica A', 32.00);

insert into product_ingredients (product_id, ingredient_id, quantity, unit)
values ('a2000000-0000-0000-0000-000000000001', 'a1000000-0000-0000-0000-000000000001', 50, 'ml');

-- user_id omitido de propósito: deve ser preenchido sozinho via
-- "default auth.uid()" — confira depois que veio USER_A_ID.
insert into inventory_counts (id, company_id, finished_at, total_inventory_value)
values ('a3000000-0000-0000-0000-000000000001', 'COMPANY_A_ID', now(), 274.69);

insert into inventory_count_items (inventory_count_id, ingredient_id, closed_quantity, fraction_quantity, total_quantity, unit_cost_at_count, total_value)
values ('a3000000-0000-0000-0000-000000000001', 'a1000000-0000-0000-0000-000000000001', 2, 0.5, 1875, 0.1465, 274.69);

-- Deve retornar USER_A_ID (confirma o default do campo):
select user_id from inventory_counts where id = 'a3000000-0000-0000-0000-000000000001';
commit;

-- =========================================================================
-- 2. Usuário B: bootstrap da Empresa B + ficha técnica/contagem (mesma
--    lógica do passo 1, troque USER_A_ID -> USER_B_ID e os IDs "a..." -> "b...")
-- =========================================================================
-- (repita o padrão do passo 1 com o Usuário B e anote COMPANY_B_ID)

-- =========================================================================
-- 3. Como Usuário A: leituras cruzadas — todas devem retornar 0
-- =========================================================================
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_A_ID", "role": "authenticated"}';

select count(*) from companies where id = 'COMPANY_B_ID';
select count(*) from ingredients where id = 'b1000000-0000-0000-0000-000000000001';
select count(*) from products where id = 'b2000000-0000-0000-0000-000000000001';
select count(*) from inventory_counts where id = 'b3000000-0000-0000-0000-000000000001';
select count(*) from product_ingredients where product_id = 'b2000000-0000-0000-0000-000000000001';
select count(*) from inventory_count_items where inventory_count_id = 'b3000000-0000-0000-0000-000000000001';
select count(*) from company_users where company_id = 'COMPANY_B_ID';

-- Controle positivo (>= 1):
select count(*) from ingredients where company_id = 'COMPANY_A_ID';
rollback;

-- =========================================================================
-- 4. Como Usuário A: escritas cruzadas — todas devem afetar 0 linhas
-- =========================================================================
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_A_ID", "role": "authenticated"}';

update ingredients set name = 'Hackeado' where id = 'b1000000-0000-0000-0000-000000000001';
update product_ingredients set quantity = 999 where product_id = 'b2000000-0000-0000-0000-000000000001';
delete from inventory_count_items where inventory_count_id = 'b3000000-0000-0000-0000-000000000001';
update inventory_counts set total_inventory_value = 0 where id = 'b3000000-0000-0000-0000-000000000001';
rollback;

-- =========================================================================
-- 5. Ataques de privilégio como Usuário A — cada um em transação própria,
--    todos devem FALHAR com erro de RLS
-- =========================================================================

-- 5.1 Autoassociação (a falha original desta revisão): A tenta se tornar
--     dono da Empresa B só inserindo em company_users.
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_A_ID", "role": "authenticated"}';
insert into company_users (company_id, user_id, role, is_owner)
values ('COMPANY_B_ID', 'USER_A_ID', 'proprietario', true);
rollback;

-- 5.2 Autoelevação: A tenta mudar o próprio role/is_owner (sem policy de UPDATE).
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_A_ID", "role": "authenticated"}';
update company_users set is_owner = true, role = 'proprietario' where user_id = 'USER_A_ID';
-- Deve mostrar "UPDATE 0" — nenhuma linha visível para update, não por erro
-- explícito, mas porque não há policy nenhuma cobrindo UPDATE nessa tabela.
rollback;

-- 5.3 Spoof de responsável: A tenta abrir uma contagem em nome de B.
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_A_ID", "role": "authenticated"}';
insert into inventory_counts (company_id, user_id) values ('COMPANY_A_ID', 'USER_B_ID');
rollback;

-- 5.4 INSERT direto em companies, sem passar pelo bootstrap.
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_A_ID", "role": "authenticated"}';
insert into companies (cnpj, legal_name, segment, employee_range, city, state)
values ('99999999000199', 'Empresa Via Insert Direto', 'bar', 'somente_eu', 'São Paulo', 'SP');
rollback;

-- 5.5 company_id imutável: A tenta mover o próprio produto para a Empresa B
--     (da qual ele não é membro) — já bloqueado só pelo RLS, mas o trigger
--     de imutabilidade também dispara. Usamos `products` (não `ingredients`)
--     de propósito: mover o company_id de um ingredient também dispara o
--     trigger de integridade "categoria pertence à mesma empresa" (5.2/6.3),
--     misturando dois triggers no mesmo teste. `products` não tem essa
--     dependência, então qualquer bloqueio aqui vem só do trigger de
--     imutabilidade. O teste que realmente prova que o trigger é necessário
--     (não só o RLS) é o 6.5, com o Usuário C.
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_A_ID", "role": "authenticated"}';
update products set company_id = 'COMPANY_B_ID' where id = 'a2000000-0000-0000-0000-000000000001';
rollback;

-- =========================================================================
-- 6. Usuário C, membro de DUAS empresas — prova que os triggers de
--    integridade protegem mesmo quando o RLS sozinho permitiria (C é
--    membro legítimo de A e de B). O app hoje não tem um jeito de deixar
--    alguém membro de duas empresas, então este vínculo é inserido "por
--    fora" (service_role), simulando um futuro recurso de convite.
-- =========================================================================
begin;
set local role service_role;
insert into profiles (id, name, email) values ('USER_C_ID', 'Usuário Teste C', 'teste-c@example.com');
insert into company_users (company_id, user_id, role, is_owner) values
  ('COMPANY_A_ID', 'USER_C_ID', 'gerente', false),
  ('COMPANY_B_ID', 'USER_C_ID', 'gerente', false);
commit;

-- 6.1 Product.company = Ingredient.company — deve falhar.
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_C_ID", "role": "authenticated"}';
-- controle: C realmente enxerga os dois lados (prova que só o trigger protege aqui)
select count(*) from products where id = 'a2000000-0000-0000-0000-000000000001';
select count(*) from ingredients where id = 'b1000000-0000-0000-0000-000000000001';
insert into product_ingredients (product_id, ingredient_id, quantity, unit)
values ('a2000000-0000-0000-0000-000000000001', 'b1000000-0000-0000-0000-000000000001', 10, 'ml');
rollback;

-- 6.2 InventoryCount.company = Ingredient.company — deve falhar.
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_C_ID", "role": "authenticated"}';
insert into inventory_count_items (inventory_count_id, ingredient_id, closed_quantity, fraction_quantity, total_quantity, unit_cost_at_count, total_value)
values ('a3000000-0000-0000-0000-000000000001', 'b1000000-0000-0000-0000-000000000001', 1, 0, 1000, 0.0899, 89.90);
rollback;

-- 6.3 Ingredient.company = Category.company — deve falhar.
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_C_ID", "role": "authenticated"}';
insert into ingredients (company_id, category_id, name, purchase_unit, usage_unit, package_content, package_price)
values ('COMPANY_A_ID', 'b1c00000-0000-0000-0000-000000000001', 'Insumo Misturado', 'unidade', 'unidade', 1, 10);
rollback;

-- 6.4 Controle positivo — mesma operação, mas com insumo/categoria da
--     PRÓPRIA empresa, deve funcionar normalmente para C.
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_C_ID", "role": "authenticated"}';
insert into ingredients (company_id, category_id, name, purchase_unit, usage_unit, package_content, package_price)
values ('COMPANY_A_ID', 'a1c00000-0000-0000-0000-000000000001', 'Insumo Correto de C em A', 'unidade', 'unidade', 1, 10);
rollback;

-- 6.5 company_id imutável — o teste que importa: C é membro LEGÍTIMO de A
--     e de B, então a policy de UPDATE (private.is_member_of_company nos
--     dois lados, avaliados de forma independente) sozinha permitiria mover
--     o produto de A para B. Só o trigger de imutabilidade impede — deve
--     falhar. Usamos `products` pelo mesmo motivo do 5.5 (ver comentário lá).
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_C_ID", "role": "authenticated"}';
update products set company_id = 'COMPANY_B_ID' where id = 'a2000000-0000-0000-0000-000000000001';
rollback;

-- 6.6 Controle: sem tentar mudar company_id, C consegue atualizar
--     normalmente outros campos do mesmo produto — prova que o trigger
--     bloqueia só a mudança de empresa, não o UPDATE em geral.
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_C_ID", "role": "authenticated"}';
update products set sale_price = 35.00 where id = 'a2000000-0000-0000-0000-000000000001';
select sale_price from products where id = 'a2000000-0000-0000-0000-000000000001'; -- deve mostrar 35.00
rollback;

-- 6.7 Mesmo ataque do 6.5, mas em service_role (bypassrls = true) — deve
--     falhar do mesmo jeito, provando que o trigger, diferente do RLS,
--     protege até papéis privilegiados.
begin;
set local role service_role;
update products set company_id = 'COMPANY_B_ID' where id = 'a2000000-0000-0000-0000-000000000001';
rollback;

-- 6.8 Bônus: mesmo ataque em `ingredients` (que tem category_id) — também
--     deve falhar, mas pelo trigger de integridade "categoria pertence à
--     mesma empresa" (5.2/6.3), não pelo de imutabilidade. Não é uma falha;
--     é redundância esperada quando duas invariantes diferentes protegem o
--     mesmo caminho.
begin;
set local role authenticated;
set local request.jwt.claims to '{"sub": "USER_C_ID", "role": "authenticated"}';
update ingredients set company_id = 'COMPANY_B_ID' where id = 'a1000000-0000-0000-0000-000000000001';
rollback;

-- =========================================================================
-- 7. Repita os blocos 3, 4 e 5 como Usuário B (trocando USER_A_ID <->
--    USER_B_ID e COMPANY_A_ID <-> COMPANY_B_ID) para confirmar o
--    isolamento nos dois sentidos.
-- =========================================================================

-- =========================================================================
-- 8. Limpeza dos dados de teste (rode como service_role/postgres, fora do
--    bloco de simulação de usuário)
-- =========================================================================
-- delete from inventory_counts where company_id in ('COMPANY_A_ID', 'COMPANY_B_ID');
-- delete from products where company_id in ('COMPANY_A_ID', 'COMPANY_B_ID');
-- delete from ingredients where company_id in ('COMPANY_A_ID', 'COMPANY_B_ID');
-- delete from companies where id in ('COMPANY_A_ID', 'COMPANY_B_ID');
-- delete from profiles where id in ('USER_A_ID', 'USER_B_ID', 'USER_C_ID');
