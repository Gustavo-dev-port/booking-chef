# Banco de dados — Estoque & Ficha Técnica

Este diretório contém as migrations SQL da Fundação (Fase 2, M0.3–M0.5). **M0.5 está concluído**: as 8 migrations foram aplicadas e o `isolation_test.sql` foi executado com sucesso contra o projeto Supabase real (`barcontrol-dev`), além de terem sido validadas antes contra um Postgres 16 local com uma emulação do schema `auth` do Supabase (ver "Como isto foi validado" abaixo).

## Migrations (`migrations/`)

Aplique nesta ordem (é a ordem alfabética/numérica dos arquivos):

1. `20260815000001_helpers.sql` — função genérica `set_updated_at()` + criação do schema `private` (funções internas, nunca expostas como RPC — ver "Hardening de funções" abaixo).
2. `20260815000002_schema.sql` — todas as tabelas, constraints e foreign keys.
3. `20260815000003_indexes.sql` — índices de apoio.
4. `20260815000004_authorization_functions.sql` — `private.is_member_of_company()` e `private.is_admin_user()`.
5. `20260815000005_rls.sql` — habilita RLS e cria todas as policies.
6. `20260815000006_bootstrap_and_integrity.sql` — `create_company_with_owner()` (bootstrap seguro de empresa), bloqueio de autoelevação em `company_users` e triggers de integridade "mesma empresa" entre tabelas relacionadas.
7. `20260815000007_immutable_company_id.sql` — trigger `prevent_company_id_change()`, bloqueando `UPDATE` que altere `company_id` em `ingredient_categories`, `ingredients`, `products` e `inventory_counts` (mesma proteção que `company_users` já tinha desde a migration 6, agora estendida às tabelas de domínio).
8. `20260815000008_revoke_anon_execute.sql` — `revoke execute ... from anon` em `create_company_with_owner()`. Achado real do advisor de segurança do Supabase depois de aplicar as migrations 1–7 no projeto real: o Supabase concede `EXECUTE` automaticamente a `anon`/`authenticated`/`service_role` em toda função nova do schema `public` (default privileges da própria plataforma), e o `revoke all ... from public` da migration 6 não alcançava esses grants diretos. Nunca foi explorável de fato (a função já rejeita qualquer chamada sem `auth.uid()`), mas violava least-privilege — ver "Revisão de segurança 6" em `docs/FASE1-ARQUITETURA.md`.

### Hardening de funções (revisão de segurança 5 e 6)

- **Schema `private`:** todas as funções que o cliente nunca precisa chamar diretamente (helpers de RLS, funções de trigger) ficam em `private`, sem `USAGE` para `PUBLIC`. O PostgREST do Supabase só expõe como RPC as funções do(s) schema(s) em **Project Settings → API → Exposed schemas** (padrão: só `public`) — isso tira essas funções da API pública sem depender de lembrar de revogar `EXECUTE` uma a uma. `create_company_with_owner()` continua em `public` de propósito: é a única que o cliente chama via `supabase.rpc(...)`.
- **`search_path = ''` em toda função:** fecha o vetor de "search_path hijacking" (mesma família do CVE-2018-1058 do Postgres) — sem um search_path fixo, um nome não qualificado dentro da função é resolvido pelo search_path de quem chama, não de quem definiu; com `search_path = ''`, nada é resolvido implicitamente (só `pg_catalog`) e toda tabela é referenciada com o schema explícito (`public.companies` etc.). Isso importa mais para `create_company_with_owner()`, por ser `SECURITY DEFINER` (roda com os privilégios de quem a definiu, não de quem chama), mas foi aplicado a todas as funções por consistência.
- **`anon` sem EXECUTE em `create_company_with_owner()`:** ver migration 8 acima — corrigido e confirmado via `has_function_privilege('anon', ..., 'execute')` retornando `false`.
- Confirmado no painel do projeto real que Project Settings → API → Exposed schemas contém só `public` — o schema `private` não é alcançável via REST/RPC.

### Modelo de embalagem e custo unitário (`ingredients`)

- `package_price`: preço pago por **uma** unidade de `purchase_unit` (uma garrafa, uma caixa — nunca um lote de várias).
- `package_content`: quanto de `usage_unit` existe dentro de **uma** unidade de `purchase_unit` (ex.: `750` ml numa garrafa; `24` unidades numa caixa).
- `unit_cost` (coluna gerada): `package_price / package_content`.

Não existe campo `package_quantity` — um campo com esse nome existiu numa revisão anterior, mas só fazia sentido para compra em lote (fora do escopo do produto) e causava confusão com `package_content`. Removido; ver seção "Revisão de segurança 4" em `docs/FASE1-ARQUITETURA.md`.

### Importante para quem for integrar o front-end

Depois da migration 6, **não existe mais INSERT direto em `companies` nem em `company_users`** — isso foi removido de propósito (ver changelog na seção "Revisão de segurança 3" do `docs/FASE1-ARQUITETURA.md`). Criar uma empresa é sempre:

```ts
const { data, error } = await supabase.rpc('create_company_with_owner', {
  p_cnpj: '12345678000190',
  p_legal_name: 'Razão Social Ltda',
  p_trade_name: 'Nome Fantasia',
  p_segment: 'bar',
  p_employee_range: 'somente_eu',
  p_city: 'São Paulo',
  p_state: 'SP',
})
```

Isso cria a empresa e o vínculo de dono (`role = 'proprietario'`, `is_owner = true`) na mesma transação, do lado do servidor — nunca dois `.insert()` separados vindos do cliente.

### Status atual do projeto real (`barcontrol-dev`)

As 8 migrations já estão aplicadas no projeto Supabase real (`gbiftkfjoeziqgrahtnj`, região `sa-east-1`), aplicadas via MCP connector do Supabase. `web/.env.local` já está preenchido com a URL do projeto e a publishable key. Não é necessário reaplicar nada — só rodar migrations novas quando existirem, na ordem, a partir da 9.

### Como aplicar (migrations futuras)

Com o [Supabase CLI](https://supabase.com/docs/guides/cli) instalado e o projeto vinculado:

```bash
supabase link --project-ref gbiftkfjoeziqgrahtnj
supabase db push
```

Alternativamente, cole o conteúdo de cada arquivo novo no **SQL Editor** do painel do Supabase, ou peça para eu aplicar via MCP connector do Supabase (já conectado nesta sessão).

## Teste de isolamento (`tests/isolation_test.sql`) — M0.5, concluído

O script já foi executado com sucesso de ponta a ponta contra o projeto real (todos os dados de teste foram removidos ao final — o banco está limpo). Ele fica no repositório como regressão para rodar de novo sempre que uma migration de segurança/RLS for adicionada. Passo a passo para uma nova rodada:

1. Aplique as migrations novas (se houver) além das 8 já aplicadas.
2. Crie três usuários de teste (Authentication → Add user, `supabase.auth.signUp`, ou um INSERT direto em `auth.users` como foi feito nesta sessão via MCP). O terceiro (`USER_C_ID`) simula alguém que é membro de duas empresas.
3. Abra `tests/isolation_test.sql`, substitua `USER_A_ID`, `USER_B_ID`, `USER_C_ID`, `COMPANY_A_ID` e `COMPANY_B_ID` pelos valores reais (os dois últimos só existem depois de rodar os passos 1 e 2 do script, que chamam `create_company_with_owner()`).
4. Rode os blocos no SQL Editor **na ordem**, um de cada vez (cada bloco é sua própria transação).
5. Confira os resultados contra os comentários "deve"/"NÃO deve" em cada bloco. Além do isolamento básico (seções 3–4), o script cobre os pontos da revisão de segurança 3: autoassociação em `company_users` (5.1), autoelevação de `role`/`is_owner` (5.2), spoof de `inventory_counts.user_id` (5.3), `INSERT` direto em `companies` sem passar pelo bootstrap (5.4), mistura de entidades entre empresas por um usuário membro das duas (seção 6 — o teste mais importante da revisão 3, porque é o único caso em que o RLS sozinho *permitiria* e só os triggers de integridade impedem), a tentativa de mover um registro entre empresas alterando `company_id` diretamente (5.5 e 6.5, revisão 4), e — da revisão 5 — o mesmo ataque de imutabilidade repetido via `service_role` (6.7, prova que o trigger vale além do RLS) e um controle mostrando que um `UPDATE` que não toca `company_id` continua funcionando normalmente (6.6).
6. Limpe os dados de teste ao final (seção 8 do script) — não deixe usuários/empresas de teste no projeto real.

Critério de aprovação (igual ao documento de arquitetura): se qualquer consulta marcada "NÃO deve retornar linhas" retornar alguma linha, qualquer UPDATE/DELETE cruzado afetar mais de 0 linhas, ou qualquer operação marcada "deve falhar" for bem-sucedida, a alteração correspondente não avança — a policy/trigger precisa ser corrigida e o teste rodado de novo.

## Como isto foi validado

Duas rodadas de validação, cada vez mais próximas do ambiente real:

1. **Local:** um Postgres 16 local com uma emulação do schema `auth` do Supabase (tabela `auth.users`, função `auth.uid()` lendo `request.jwt.claims`, papéis `authenticated`/`service_role`/`anon`) rodando as 8 migrations e o `isolation_test.sql` real de ponta a ponta, com o banco recriado do zero a cada revisão de segurança.
2. **Projeto Supabase real (`barcontrol-dev`):** as 8 migrations aplicadas via `apply_migration` do MCP connector do Supabase, seguidas do advisor de segurança (`get_advisors`, tipo `security`) — que pegou o achado real da revisão 6 (`anon` com `EXECUTE` indevido) — e do `isolation_test.sql` real executado do início ao fim via `execute_sql`, cobrindo isolamento básico, os 5 ataques de privilégio (incluindo imutabilidade de `company_id`), os 8 cenários de mistura entre empresas com o usuário C, e a checagem de simetria com o usuário B. Todos os resultados bateram com o esperado. Os dados de teste foram removidos ao final.

M0.5 está formalmente concluído.
