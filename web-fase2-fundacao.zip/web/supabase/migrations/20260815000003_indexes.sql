-- M0.3 — Fundação: índices de apoio para RLS e busca instantânea.

create index idx_company_users_user_id on company_users (user_id);
create index idx_company_users_company_id on company_users (company_id);

create index idx_ingredient_categories_company_id on ingredient_categories (company_id);

create index idx_ingredients_company_id on ingredients (company_id);
create index idx_ingredients_company_name on ingredients (company_id, name);
create index idx_ingredients_category_id on ingredients (category_id);

create index idx_products_company_id on products (company_id);
create index idx_products_company_name on products (company_id, name);

create index idx_product_ingredients_product_id on product_ingredients (product_id);
create index idx_product_ingredients_ingredient_id on product_ingredients (ingredient_id);

create index idx_inventory_counts_company_id on inventory_counts (company_id);
create index idx_inventory_counts_user_id on inventory_counts (user_id);

create index idx_inventory_count_items_inventory_count_id on inventory_count_items (inventory_count_id);
create index idx_inventory_count_items_ingredient_id on inventory_count_items (ingredient_id);

create index idx_analytics_events_company_id on analytics_events (company_id);
create index idx_analytics_events_event_name on analytics_events (event_name);
