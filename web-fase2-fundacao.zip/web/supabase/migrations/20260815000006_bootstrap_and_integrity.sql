-- Revisão de segurança 3 (pós-Fundação, pré-Fase 3): bootstrap seguro de
-- empresa, bloqueio de autoelevação e integridade de "mesma empresa" entre
-- tabelas relacionadas. Ver web/docs/FASE1-ARQUITETURA.md para o
-- changelog completo desta revisão.

-- =========================================================================
-- 1) Bootstrap seguro: create_company_with_owner()
-- =========================================================================
-- Substitui o INSERT direto em companies + company_users que existia nas
-- policies originais (removidas em 20260815000005_rls.sql). SECURITY
-- DEFINER: roda com os privilégios de quem definiu a função (o dono do
-- schema), não do chamador — por isso ela PRECISA validar auth.uid() e
-- montar os dois INSERTs internamente, em vez de confiar em qualquer valor
-- vindo do cliente. role é sempre 'proprietario' e is_owner sempre true
-- para quem cria a empresa; não há parâmetro para o cliente escolher isso.
--
-- Fica em `public` de propósito (revisão de segurança 5): é a única função
-- desta migration que o cliente PRECISA chamar via supabase.rpc(), então
-- não pode ir para o schema `private`. Em compensação, é a que mais precisa
-- de search_path='' — sendo SECURITY DEFINER, roda com os privilégios do
-- dono da função; sem um search_path fixo e referências totalmente
-- qualificadas (`public.companies`, `public.company_users`), ela ficaria
-- vulnerável a um objeto de mesmo nome criado mais cedo no search_path de
-- quem chama ("search_path hijacking" — CVE-2018-1058).
create or replace function create_company_with_owner(
  p_cnpj text,
  p_legal_name text,
  p_trade_name text,
  p_segment text,
  p_employee_range text,
  p_city text,
  p_state text
)
returns public.companies
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_company public.companies;
begin
  if auth.uid() is null then
    raise exception 'Usuário não autenticado.' using errcode = '28000';
  end if;

  insert into public.companies (cnpj, legal_name, trade_name, segment, employee_range, city, state)
  values (p_cnpj, p_legal_name, p_trade_name, p_segment, p_employee_range, p_city, p_state)
  returning * into v_company;

  insert into public.company_users (company_id, user_id, role, is_owner)
  values (v_company.id, auth.uid(), 'proprietario', true);

  return v_company;
end;
$$;

comment on function create_company_with_owner(text, text, text, text, text, text, text) is
  'Único caminho para criar uma empresa: cria companies + company_users (dono) atomicamente. SECURITY DEFINER, search_path='''' e referências totalmente qualificadas — o cliente não tem mais INSERT direto em nenhuma das duas tabelas.';

revoke all on function create_company_with_owner(text, text, text, text, text, text, text) from public;
grant execute on function create_company_with_owner(text, text, text, text, text, text, text) to authenticated;

-- =========================================================================
-- 2) Proibir autoelevação em company_users (defesa em profundidade)
-- =========================================================================
-- Já não existe policy de UPDATE em company_users (ver 20260815000005_rls.sql),
-- então isto não deveria nem ser alcançado pelo papel `authenticated`. O
-- trigger existe como segunda camada de proteção, válida inclusive para
-- `service_role` (que ignora RLS mas NÃO ignora triggers): qualquer
-- alteração de role, is_owner, company_id ou user_id numa linha existente
-- é rejeitada. Reatribuir dono/mover de empresa não são operações
-- suportadas nesta fase — se algum dia forem, precisam de uma função
-- dedicada e auditável, não de um UPDATE aberto.
--
-- Função de trigger: schema `private` + search_path='' (revisão de
-- segurança 5). Mover schema não exige recriar o trigger — o Postgres
-- referencia a função por OID internamente, não por nome.
create or replace function private.prevent_company_users_privilege_change()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.role is distinct from old.role
     or new.is_owner is distinct from old.is_owner
     or new.company_id is distinct from old.company_id
     or new.user_id is distinct from old.user_id then
    raise exception
      'Alteração de role/is_owner/company_id/user_id em company_users não é permitida diretamente.'
      using errcode = '42501';
  end if;
  return new;
end;
$$;

create trigger trg_company_users_prevent_privilege_escalation
  before update on company_users
  for each row execute function private.prevent_company_users_privilege_change();

-- =========================================================================
-- 3) Integridade "mesma empresa" entre tabelas relacionadas
-- =========================================================================
-- RLS sozinho não impede um usuário que é membro de DUAS empresas (A e B)
-- de misturar entidades das duas numa mesma ficha técnica ou contagem —
-- private.is_member_of_company(a) e private.is_member_of_company(b) seriam
-- ambos verdadeiros. Estes triggers garantem a invariante no banco,
-- independentemente de quantas empresas o usuário puder acessar.
--
-- Todas em schema `private` + search_path='' (revisão de segurança 5),
-- com as tabelas lidas de forma totalmente qualificada (`public.products`,
-- `public.ingredients` etc.).

-- Product.company = Ingredient.company
create or replace function private.check_product_ingredient_company()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  v_product_company uuid;
  v_ingredient_company uuid;
begin
  select company_id into v_product_company from public.products where id = new.product_id;
  select company_id into v_ingredient_company from public.ingredients where id = new.ingredient_id;

  if v_product_company is null or v_ingredient_company is null then
    raise exception 'Produto ou insumo inexistente em product_ingredients.';
  end if;

  if v_product_company <> v_ingredient_company then
    raise exception
      'O insumo pertence a uma empresa diferente do produto (product_ingredients).'
      using errcode = '23514';
  end if;

  return new;
end;
$$;

create trigger trg_product_ingredients_same_company
  before insert or update on product_ingredients
  for each row execute function private.check_product_ingredient_company();

-- InventoryCount.company = Ingredient.company
create or replace function private.check_inventory_count_item_company()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  v_count_company uuid;
  v_ingredient_company uuid;
begin
  select company_id into v_count_company from public.inventory_counts where id = new.inventory_count_id;
  select company_id into v_ingredient_company from public.ingredients where id = new.ingredient_id;

  if v_count_company is null or v_ingredient_company is null then
    raise exception 'Contagem ou insumo inexistente em inventory_count_items.';
  end if;

  if v_count_company <> v_ingredient_company then
    raise exception
      'O insumo pertence a uma empresa diferente da contagem (inventory_count_items).'
      using errcode = '23514';
  end if;

  return new;
end;
$$;

create trigger trg_inventory_count_items_same_company
  before insert or update on inventory_count_items
  for each row execute function private.check_inventory_count_item_company();

-- Ingredient.company = Category.company
create or replace function private.check_ingredient_category_company()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  v_category_company uuid;
begin
  if new.category_id is null then
    return new;
  end if;

  select company_id into v_category_company
  from public.ingredient_categories
  where id = new.category_id;

  if v_category_company is null then
    raise exception 'Categoria inexistente em ingredients.';
  end if;

  if v_category_company <> new.company_id then
    raise exception
      'A categoria pertence a uma empresa diferente do insumo (ingredients).'
      using errcode = '23514';
  end if;

  return new;
end;
$$;

create trigger trg_ingredients_category_same_company
  before insert or update on ingredients
  for each row execute function private.check_ingredient_category_company();
