-- M0.3 — Fundação: funções auxiliares genéricas (sem dependência de tabelas
-- de domínio). gen_random_uuid() já é nativa no Postgres 13+ usado pelo
-- Supabase, não é necessário habilitar a extensão pgcrypto.

-- Revisão de segurança 5: schema `private` para funções que NUNCA devem
-- ser chamadas diretamente por um cliente (helpers de RLS e funções de
-- trigger). O PostgREST do Supabase só expõe como RPC as funções do(s)
-- schema(s) configurado(s) em "Exposed schemas" (por padrão, só `public`)
-- — qualquer função aqui dentro fica automaticamente fora dessa API, sem
-- depender de lembrar de revogar EXECUTE função por função. `search_path`
-- explícito nas próprias funções (ver migrations seguintes) é a segunda
-- camada: garante que, mesmo chamadas por dentro de outra função, elas só
-- resolvem nomes de objeto exatamente onde deveriam.
create schema if not exists private;

comment on schema private is
  'Funções internas (helpers de RLS, funções de trigger) — nunca exposto como RPC pelo PostgREST. Não colocar aqui nada que o cliente precise chamar via supabase.rpc().';

revoke all on schema private from public;
grant usage on schema private to authenticated, service_role;

create or replace function set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

comment on function set_updated_at() is
  'Trigger genérico: mantém updated_at sincronizado em qualquer UPDATE.';
