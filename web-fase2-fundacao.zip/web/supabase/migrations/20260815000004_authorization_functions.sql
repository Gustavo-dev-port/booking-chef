-- M0.4 — Row Level Security: funções auxiliares de autorização.
--
-- Nota sobre recursão de RLS: estas funções rodam com os privilégios de
-- quem chama (security invoker, padrão). Isso só é seguro porque as
-- policies de company_users e admin_users (ver próxima migration) usam
-- comparação DIRETA (user_id = auth.uid()), sem chamar estas funções — caso
-- contrário, a subconsulta dentro da função reativaria a mesma policy
-- recursivamente e o Postgres retornaria erro de profundidade de pilha.
--
-- Revisão de segurança 5: movidas para o schema `private` (não exposto
-- como RPC pelo PostgREST — ver 20260815000001_helpers.sql) e com
-- `search_path = ''`, referenciando `public.company_users`/
-- `public.admin_users` de forma totalmente qualificada. Isso fecha o
-- vetor clássico de "search_path hijacking": sem um search_path fixo, um
-- nome não qualificado dentro da função é resolvido usando o search_path
-- da sessão de quem chama, não o de quem definiu a função — se alguém
-- conseguisse criar um objeto com o mesmo nome num schema mais cedo nesse
-- search_path, a função passaria a operar sobre o objeto errado. Com
-- search_path = '' isso é impossível: só pg_catalog é resolvido
-- implicitamente, tudo o mais precisa vir com o schema explícito.

create or replace function private.is_member_of_company(target_company_id uuid)
returns boolean
language sql
stable
security invoker
set search_path = ''
as $$
  select exists (
    select 1
    from public.company_users cu
    where cu.company_id = target_company_id
      and cu.user_id = auth.uid()
  );
$$;

comment on function private.is_member_of_company(uuid) is
  'True se o usuário autenticado pertence à empresa informada. Usada nas policies das tabelas pai (ingredients, ingredient_categories, products, inventory_counts) e, via entidade pai, nas tabelas filhas. Schema private: não é RPC pública.';

revoke all on function private.is_member_of_company(uuid) from public;
grant execute on function private.is_member_of_company(uuid) to authenticated;

create or replace function private.is_admin_user()
returns boolean
language sql
stable
security invoker
set search_path = ''
as $$
  select exists (
    select 1
    from public.admin_users au
    where au.user_id = auth.uid()
  );
$$;

comment on function private.is_admin_user() is
  'True se o usuário autenticado está cadastrado em admin_users. Nunca usar e-mail como mecanismo de autorização administrativa. Schema private: não é RPC pública.';

revoke all on function private.is_admin_user() from public;
grant execute on function private.is_admin_user() to authenticated;
