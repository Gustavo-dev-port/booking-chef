-- M0.4 — Row Level Security.
--
-- Princípio inegociável (ver FASE1-ARQUITETURA.md, seção 9): um filtro como
-- .eq("company_id", companyId) no front-end NUNCA é considerado proteção
-- suficiente. Toda a proteção real está aqui, nas policies do Postgres.

alter table profiles enable row level security;
alter table companies enable row level security;
alter table company_users enable row level security;
alter table ingredient_categories enable row level security;
alter table ingredients enable row level security;
alter table products enable row level security;
alter table product_ingredients enable row level security;
alter table inventory_counts enable row level security;
alter table inventory_count_items enable row level security;
alter table units_conversion enable row level security;
alter table analytics_events enable row level security;
alter table admin_users enable row level security;

-- =========================================================================
-- profiles — cada usuário só enxerga/edita o próprio perfil
-- =========================================================================
create policy "profiles_select_own" on profiles
  for select using (id = auth.uid());

create policy "profiles_insert_own" on profiles
  for insert with check (id = auth.uid());

create policy "profiles_update_own" on profiles
  for update using (id = auth.uid()) with check (id = auth.uid());

-- Sem policy de DELETE: exclusão de perfil não é uma operação do app nesta fase.

-- =========================================================================
-- companies
-- =========================================================================
create policy "companies_select_member" on companies
  for select using (private.is_member_of_company(id));

create policy "companies_update_member" on companies
  for update using (private.is_member_of_company(id)) with check (private.is_member_of_company(id));

-- SEM policy de INSERT (revisão 3 / Ajuste 1 da revisão de segurança):
-- a autoassociação foi removida de propósito. Criar uma empresa não pode
-- ser um INSERT direto do cliente, porque não existe ainda vínculo em
-- company_users que limite QUAL company_id o usuário pode escolher — um
-- INSERT liberado para "qualquer autenticado" cria a empresa, mas nada
-- impede o próximo passo (vincular-se a ela) de ser feito para uma empresa
-- de outra pessoa. Criação de empresa agora é exclusivamente via
-- create_company_with_owner() (ver 20260815000006_bootstrap_and_integrity.sql),
-- que cria a empresa E o vínculo de dono na mesma transação, sob controle
-- do servidor (SECURITY DEFINER), nunca do cliente.
--
-- Sem policy de DELETE: apagar uma empresa inteira não é uma operação do
-- app nesta fase (fica restrito a administração fora do RLS de cliente).

-- =========================================================================
-- company_users — comparação DIRETA (ver nota sobre recursão na migration
-- 20260815000004_authorization_functions.sql)
-- =========================================================================
create policy "company_users_select_own" on company_users
  for select using (user_id = auth.uid());

-- SEM policy de INSERT (revisão 3): esta era a falha de autoassociação —
-- "with check (user_id = auth.uid())" permitia que qualquer usuário
-- autenticado se vinculasse como dono (is_owner = true) a QUALQUER
-- company_id existente, inclusive de outra empresa, bastando conhecer o
-- UUID. O único jeito de ganhar uma linha em company_users agora é através
-- de create_company_with_owner() (SECURITY DEFINER, força
-- role = 'proprietario' e is_owner = true só para quem acabou de criar a
-- empresa). Convite de um segundo membro fica fora do escopo do MVP e,
-- quando existir, também precisará de uma função dedicada — nunca de um
-- INSERT direto liberado ao cliente.
--
-- SEM policy de UPDATE (revisão 3 / Ajuste 3): impede autoelevação de
-- role/is_owner (ver também o trigger de defesa em profundidade em
-- 20260815000006_bootstrap_and_integrity.sql, que bloqueia a alteração
-- mesmo que uma policy de UPDATE venha a ser adicionada no futuro sem esse
-- cuidado).
--
-- Sem policy de DELETE: remover um membro de uma empresa não é uma
-- operação do app nesta fase.

-- =========================================================================
-- ingredient_categories (tabela pai)
-- =========================================================================
create policy "ingredient_categories_select" on ingredient_categories
  for select using (private.is_member_of_company(company_id));

create policy "ingredient_categories_insert" on ingredient_categories
  for insert with check (private.is_member_of_company(company_id));

create policy "ingredient_categories_update" on ingredient_categories
  for update using (private.is_member_of_company(company_id)) with check (private.is_member_of_company(company_id));

create policy "ingredient_categories_delete" on ingredient_categories
  for delete using (private.is_member_of_company(company_id));

-- =========================================================================
-- ingredients (tabela pai)
-- =========================================================================
create policy "ingredients_select" on ingredients
  for select using (private.is_member_of_company(company_id));

create policy "ingredients_insert" on ingredients
  for insert with check (private.is_member_of_company(company_id));

create policy "ingredients_update" on ingredients
  for update using (private.is_member_of_company(company_id)) with check (private.is_member_of_company(company_id));

create policy "ingredients_delete" on ingredients
  for delete using (private.is_member_of_company(company_id));

-- =========================================================================
-- products (tabela pai)
-- =========================================================================
create policy "products_select" on products
  for select using (private.is_member_of_company(company_id));

create policy "products_insert" on products
  for insert with check (private.is_member_of_company(company_id));

create policy "products_update" on products
  for update using (private.is_member_of_company(company_id)) with check (private.is_member_of_company(company_id));

create policy "products_delete" on products
  for delete using (private.is_member_of_company(company_id));

-- =========================================================================
-- product_ingredients (Ajuste 1 — tabela FILHA, sem company_id próprio;
-- autorização sobe até products.company_id)
-- =========================================================================
create policy "product_ingredients_select" on product_ingredients
  for select using (
    exists (
      select 1 from products p
      where p.id = product_ingredients.product_id
        and private.is_member_of_company(p.company_id)
    )
  );

create policy "product_ingredients_insert" on product_ingredients
  for insert with check (
    exists (
      select 1 from products p
      where p.id = product_ingredients.product_id
        and private.is_member_of_company(p.company_id)
    )
  );

create policy "product_ingredients_update" on product_ingredients
  for update using (
    exists (
      select 1 from products p
      where p.id = product_ingredients.product_id
        and private.is_member_of_company(p.company_id)
    )
  ) with check (
    exists (
      select 1 from products p
      where p.id = product_ingredients.product_id
        and private.is_member_of_company(p.company_id)
    )
  );

create policy "product_ingredients_delete" on product_ingredients
  for delete using (
    exists (
      select 1 from products p
      where p.id = product_ingredients.product_id
        and private.is_member_of_company(p.company_id)
    )
  );

-- =========================================================================
-- inventory_counts (tabela pai)
-- =========================================================================
create policy "inventory_counts_select" on inventory_counts
  for select using (private.is_member_of_company(company_id));

-- user_id = auth.uid() (revisão 3 / Ajuste 7): sem isso, qualquer membro da
-- empresa poderia abrir/editar uma contagem "em nome" de outro colega só
-- informando o user_id dele — o campo default auth.uid() (ver
-- 20260815000002_schema.sql) cobre o caso de omissão; este WITH CHECK cobre
-- a tentativa explícita de informar um user_id diferente do próprio.
create policy "inventory_counts_insert" on inventory_counts
  for insert with check (private.is_member_of_company(company_id) and user_id = auth.uid());

create policy "inventory_counts_update" on inventory_counts
  for update using (private.is_member_of_company(company_id) and user_id = auth.uid())
  with check (private.is_member_of_company(company_id) and user_id = auth.uid());

create policy "inventory_counts_delete" on inventory_counts
  for delete using (private.is_member_of_company(company_id) and user_id = auth.uid());

-- =========================================================================
-- inventory_count_items (Ajuste 1 — tabela FILHA, sem company_id próprio;
-- autorização sobe até inventory_counts.company_id)
-- =========================================================================
create policy "inventory_count_items_select" on inventory_count_items
  for select using (
    exists (
      select 1 from inventory_counts ic
      where ic.id = inventory_count_items.inventory_count_id
        and private.is_member_of_company(ic.company_id)
    )
  );

create policy "inventory_count_items_insert" on inventory_count_items
  for insert with check (
    exists (
      select 1 from inventory_counts ic
      where ic.id = inventory_count_items.inventory_count_id
        and private.is_member_of_company(ic.company_id)
    )
  );

create policy "inventory_count_items_update" on inventory_count_items
  for update using (
    exists (
      select 1 from inventory_counts ic
      where ic.id = inventory_count_items.inventory_count_id
        and private.is_member_of_company(ic.company_id)
    )
  ) with check (
    exists (
      select 1 from inventory_counts ic
      where ic.id = inventory_count_items.inventory_count_id
        and private.is_member_of_company(ic.company_id)
    )
  );

create policy "inventory_count_items_delete" on inventory_count_items
  for delete using (
    exists (
      select 1 from inventory_counts ic
      where ic.id = inventory_count_items.inventory_count_id
        and private.is_member_of_company(ic.company_id)
    )
  );

-- =========================================================================
-- units_conversion — referência universal, somente leitura para
-- qualquer usuário autenticado
-- =========================================================================
create policy "units_conversion_select_authenticated" on units_conversion
  for select using (auth.uid() is not null);

-- Sem policies de escrita: mantida apenas via migration/admin.

-- =========================================================================
-- analytics_events — gravação pelo próprio usuário; leitura só por admin
-- =========================================================================
create policy "analytics_events_insert_own" on analytics_events
  for insert with check (
    user_id = auth.uid()
    and (
      company_id is null
      or private.is_member_of_company(company_id)
    )
  );

create policy "analytics_events_select_admin" on analytics_events
  for select using (private.is_admin_user());

-- Sem policies de UPDATE/DELETE: log de eventos é imutável.

-- =========================================================================
-- admin_users — comparação DIRETA (mesmo motivo de company_users: evitar
-- recursão, já que private.is_admin_user() consulta esta própria tabela)
-- =========================================================================
create policy "admin_users_select_own" on admin_users
  for select using (user_id = auth.uid());

-- Sem policies de INSERT/UPDATE/DELETE: a promoção a admin é feita fora do
-- caminho do cliente (service role / SQL direto), nunca autoatribuída.
