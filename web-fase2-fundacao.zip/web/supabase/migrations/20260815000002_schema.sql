-- M0.3 — Fundação: tabelas, constraints e foreign keys.
-- Reflete FASE1-ARQUITETURA.md, seção 5 (revisão 2).
--
-- Convenções gerais:
--   * id uuid primary key default gen_random_uuid(), exceto profiles (= auth.users.id).
--   * Somente tabelas "pai" (ingredients, ingredient_categories, products,
--     inventory_counts) carregam company_id. Tabelas filhas
--     (product_ingredients, inventory_count_items) não têm company_id
--     próprio — a autorização é resolvida via entidade pai (ver RLS na
--     migration 20260815000005_rls.sql).
--   * Dinheiro e custo sempre em numeric (nunca float/double precision).
--   * Exclusão lógica (is_active) em ingredients/products: eles são
--     referenciados por histórico (fichas técnicas e contagens) e não podem
--     ser apagados fisicamente sem quebrar esse histórico.

-- =========================================================================
-- profiles
-- =========================================================================
create table profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  name text not null,
  email text not null,
  phone text,
  terms_accepted_at timestamptz,
  marketing_opt_in boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

comment on table profiles is 'Dados complementares do usuário autenticado (1:1 com auth.users).';

create trigger trg_profiles_updated_at
  before update on profiles
  for each row execute function set_updated_at();

-- =========================================================================
-- companies
-- =========================================================================
create table companies (
  id uuid primary key default gen_random_uuid(),
  cnpj text not null,
  legal_name text not null,
  trade_name text,
  segment text not null,
  employee_range text not null,
  city text not null,
  state text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- CNPJ armazenado normalizado (só dígitos); a máscara é responsabilidade
  -- exclusiva da interface.
  constraint companies_cnpj_digits_check check (cnpj ~ '^[0-9]{14}$'),
  constraint companies_cnpj_unique unique (cnpj),

  -- Enumerações do onboarding (Etapas 3 e 4). "outro" cobre segmentos fora
  -- da lista fechada.
  constraint companies_segment_check check (
    segment in (
      'bar', 'restaurante', 'lanchonete', 'hamburgueria', 'pizzaria',
      'adega', 'cafeteria', 'food_truck', 'casa_noturna', 'outro'
    )
  ),
  constraint companies_employee_range_check check (
    employee_range in ('somente_eu', '2_a_5', '6_a_10', '11_a_20', 'mais_de_20')
  ),
  constraint companies_state_uf_check check (state ~ '^[A-Z]{2}$')
);

comment on table companies is 'Estabelecimento (tenant). Todo dado de domínio pertence a uma company.';
comment on column companies.cnpj is 'Somente dígitos (14 caracteres). Formatação fica na interface.';

create trigger trg_companies_updated_at
  before update on companies
  for each row execute function set_updated_at();

-- =========================================================================
-- company_users (N:N entre profiles e companies)
-- =========================================================================
create table company_users (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies (id) on delete cascade,
  user_id uuid not null references profiles (id) on delete cascade,
  role text not null,
  is_owner boolean not null default false,
  created_at timestamptz not null default now(),

  -- Impede vincular o mesmo usuário duas vezes à mesma empresa.
  constraint company_users_company_user_unique unique (company_id, user_id),

  -- Enumeração da Etapa 5 do onboarding.
  constraint company_users_role_check check (
    role in (
      'proprietario', 'gerente', 'administrativo_financeiro',
      'responsavel_estoque', 'bartender_cozinha', 'funcionario', 'outro'
    )
  )
);

comment on table company_users is 'Vínculo de um usuário a uma empresa (multi-tenancy).';

-- =========================================================================
-- ingredient_categories
-- =========================================================================
create table ingredient_categories (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies (id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now()
);

comment on table ingredient_categories is 'Categorias de insumo por empresa (padrão + personalizadas).';

-- =========================================================================
-- ingredients
-- =========================================================================
-- category_id é opcional (ON DELETE SET NULL): apagar uma categoria não
-- pode travar nem apagar em cascata os insumos que a usavam.
create table ingredients (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies (id) on delete cascade,
  category_id uuid references ingredient_categories (id) on delete set null,
  name text not null,
  purchase_unit text not null,
  usage_unit text not null,

  -- Modelo de embalagem (Ajuste 2, semântica corrigida na revisão 4): os
  -- dados de conversão pertencem ao próprio insumo, porque não são
  -- universais (uma garrafa de Gin tem 750 ml, uma de Vodka pode ter
  -- 1000 ml; uma caixa de cerveja tem 24 unidades, uma de refrigerante
  -- pode ter 12).
  --
  -- A versão anterior tinha um campo package_quantity ("quantas embalagens
  -- de compra o preço cobre") separado de package_content, e os dois se
  -- confundiam na prática: o exemplo da Heineken chegava a inverter os
  -- valores em relação à própria definição. A causa raiz é que
  -- package_quantity só faria sentido para representar uma compra em lote
  -- (ex.: "comprei 3 caixas de uma vez por um preço combinado") — um caso
  -- que o produto não precisa suportar (o usuário sempre informa o preço de
  -- UMA unidade de purchase_unit). Por isso o campo foi removido.
  --
  -- Semântica única e sem ambiguidade agora:
  --   package_price:   preço pago por UMA unidade de purchase_unit
  --                     (uma garrafa, uma caixa, um pacote — nunca um lote).
  --   package_content: quanto de usage_unit existe em UMA unidade de
  --                     purchase_unit (ex.: 750 ml numa garrafa; 24
  --                     unidades numa caixa).
  --
  -- Exemplos:
  --   Gin Tanqueray:  purchase_unit=garrafa, usage_unit=ml,
  --                   package_price=109.90, package_content=750
  --                   -> unit_cost = 109.90 / 750 = R$ 0,1465/ml
  --   Caixa Heineken: purchase_unit=caixa, usage_unit=unidade,
  --                   package_price=112.80, package_content=24
  --                   -> unit_cost = 112.80 / 24 = R$ 4,70/unidade
  package_content numeric not null,
  package_price numeric(12, 4) not null,

  -- unit_cost é sempre derivado — nunca gravado manualmente, para que
  -- nunca fique dessincronizado do preço/embalagem informados.
  unit_cost numeric(14, 6) generated always as (
    package_price / package_content
  ) stored,

  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint ingredients_package_content_positive check (package_content > 0),
  constraint ingredients_package_price_non_negative check (package_price >= 0)
);

comment on table ingredients is 'Insumo (ingrediente/bebida/etc.) de uma empresa; unit_cost é sempre calculado.';

create trigger trg_ingredients_updated_at
  before update on ingredients
  for each row execute function set_updated_at();

-- =========================================================================
-- products
-- =========================================================================
create table products (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies (id) on delete cascade,
  name text not null,
  category text,
  sale_price numeric(12, 2) not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint products_sale_price_non_negative check (sale_price >= 0)
);

comment on table products is 'Produto vendido pela empresa (a ficha técnica é product_ingredients).';

create trigger trg_products_updated_at
  before update on products
  for each row execute function set_updated_at();

-- =========================================================================
-- product_ingredients (ficha técnica) — tabela filha, sem company_id
-- =========================================================================
-- ON DELETE RESTRICT em ingredient_id: um insumo usado em alguma ficha
-- técnica não pode ser apagado fisicamente — a ação correta é arquivá-lo
-- (is_active = false).
create table product_ingredients (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products (id) on delete cascade,
  ingredient_id uuid not null references ingredients (id) on delete restrict,
  quantity numeric not null,
  unit text not null,
  created_at timestamptz not null default now(),

  constraint product_ingredients_quantity_non_negative check (quantity >= 0),
  -- Evita duas linhas para o mesmo insumo na mesma ficha técnica; a
  -- quantidade correta é uma soma, não duas linhas.
  constraint product_ingredients_product_ingredient_unique unique (product_id, ingredient_id)
);

comment on table product_ingredients is
  'Ficha técnica: liga products a ingredients. Custo sempre calculado via join com ingredients.unit_cost, nunca copiado aqui. Sem company_id — empresa resolvida via products.company_id.';

-- =========================================================================
-- inventory_counts
-- =========================================================================
-- user_id usa ON DELETE SET NULL (não CASCADE nem RESTRICT): se a conta do
-- responsável for removida no futuro, o histórico de contagens da empresa
-- deve ser preservado mesmo assim.
create table inventory_counts (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies (id) on delete cascade,
  -- default auth.uid(): o cliente não precisa (e não pode) informar
  -- user_id manualmente — ver também o WITH CHECK em RLS que rejeita
  -- qualquer tentativa explícita de gravar em nome de outro usuário.
  -- Nullable + ON DELETE SET NULL: preserva o histórico da contagem mesmo
  -- que a conta do responsável seja removida no futuro.
  user_id uuid references profiles (id) on delete set null default auth.uid(),
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  total_inventory_value numeric(12, 2),
  created_at timestamptz not null default now(),

  constraint inventory_counts_finished_after_started
    check (finished_at is null or finished_at >= started_at),
  constraint inventory_counts_total_value_non_negative
    check (total_inventory_value is null or total_inventory_value >= 0)
);

comment on table inventory_counts is 'Uma contagem de estoque completa (uma "fotografia" em um momento).';

-- =========================================================================
-- inventory_count_items — tabela filha, sem company_id
-- =========================================================================
-- ingredient_id usa ON DELETE RESTRICT pelo mesmo motivo de
-- product_ingredients: preserva o histórico de contagens.
create table inventory_count_items (
  id uuid primary key default gen_random_uuid(),
  inventory_count_id uuid not null references inventory_counts (id) on delete cascade,
  ingredient_id uuid not null references ingredients (id) on delete restrict,
  closed_quantity numeric not null default 0,
  fraction_quantity numeric not null default 0,
  total_quantity numeric not null,

  -- Snapshot histórico do custo no momento da contagem — nunca recalculado
  -- retroativamente, mesmo que ingredients.unit_cost mude depois.
  unit_cost_at_count numeric(14, 6) not null,
  total_value numeric(12, 2) not null,
  created_at timestamptz not null default now(),

  constraint inventory_count_items_closed_quantity_non_negative check (closed_quantity >= 0),
  constraint inventory_count_items_fraction_range check (fraction_quantity >= 0 and fraction_quantity <= 1),
  constraint inventory_count_items_total_quantity_non_negative check (total_quantity >= 0),
  constraint inventory_count_items_unit_cost_non_negative check (unit_cost_at_count >= 0),
  constraint inventory_count_items_total_value_non_negative check (total_value >= 0),
  -- Um insumo aparece no máximo uma vez por contagem.
  constraint inventory_count_items_count_ingredient_unique unique (inventory_count_id, ingredient_id)
);

comment on table inventory_count_items is
  'Item de uma contagem, com custo congelado em unit_cost_at_count. Sem company_id — empresa resolvida via inventory_counts.company_id.';

-- =========================================================================
-- units_conversion — apoio, apenas conversões universais
-- =========================================================================
-- NUNCA usar esta tabela para embalagem -> unidade de uso (isso pertence a
-- ingredients, ver Ajuste 2). Serve só para conversões matematicamente
-- universais e independentes de produto.
create table units_conversion (
  unit_from text not null,
  unit_to text not null,
  factor numeric not null,
  primary key (unit_from, unit_to),
  constraint units_conversion_factor_positive check (factor > 0)
);

comment on table units_conversion is
  'Conversões universais (kg<->g, L<->ml). Embalagem/compra pertence a ingredients, não aqui.';

insert into units_conversion (unit_from, unit_to, factor) values
  ('kg', 'g', 1000),
  ('g', 'kg', 0.001),
  ('l', 'ml', 1000),
  ('ml', 'l', 0.001);

-- =========================================================================
-- analytics_events
-- =========================================================================
-- company_id é opcional: alguns eventos (signup_completed, login) podem
-- ocorrer antes de existir uma empresa vinculada.
create table analytics_events (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies (id) on delete cascade,
  user_id uuid references profiles (id) on delete set null,
  event_name text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),

  constraint analytics_events_event_name_check check (
    event_name in (
      'signup_completed', 'company_created', 'ingredient_created',
      'first_ingredient_created', 'product_created', 'first_product_created',
      'inventory_started', 'inventory_completed', 'second_inventory_completed',
      'login'
    )
  )
);

comment on table analytics_events is 'Eventos para o funil de ativação (ver FASE1-ARQUITETURA.md, seção "Métricas").';

-- =========================================================================
-- admin_users — painel administrativo interno, nunca ligado a company_users
-- =========================================================================
create table admin_users (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  role text not null default 'admin',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint admin_users_user_id_unique unique (user_id)
);

comment on table admin_users is
  'Autorização do painel admin por identidade autenticada (user_id), nunca por e-mail. Sem relação com company_users.';

create trigger trg_admin_users_updated_at
  before update on admin_users
  for each row execute function set_updated_at();
