-- Revisão de segurança 4 (pós-Fundação): company_id imutável nas tabelas
-- pai. Ver web/docs/FASE1-ARQUITETURA.md para o changelog completo.
--
-- Motivo: a policy de UPDATE original (`private.is_member_of_company(company_id)`)
-- é avaliada tanto contra a linha antes quanto depois da mudança — mas as
-- duas avaliações são independentes uma da outra. Um usuário membro de
-- DUAS empresas (o mesmo cenário dos triggers de integridade "mesma
-- empresa" em 20260815000006) passa em ambas as checagens mesmo estando
-- "movendo" a linha de uma empresa para a outra: is_member_of_company(A)
-- é true para a linha antiga, is_member_of_company(B) é true para a linha
-- nova. Só um trigger comparando OLD.company_id com NEW.company_id fecha
-- essa brecha.
--
-- Função de trigger em schema `private` + search_path='' (revisão de
-- segurança 5), consistente com as demais funções de trigger desta base.
-- Esta função em particular não lê nenhuma tabela (só compara OLD/NEW),
-- então search_path='' não muda seu comportamento — está aqui por
-- consistência e para blindar qualquer evolução futura da função.

create or replace function private.prevent_company_id_change()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.company_id is distinct from old.company_id then
    raise exception
      'company_id é imutável — não é permitido mover um registro entre empresas.'
      using errcode = '42501';
  end if;
  return new;
end;
$$;

comment on function private.prevent_company_id_change() is
  'Trigger genérico: bloqueia UPDATE que altere company_id em qualquer tabela pai.';

create trigger trg_ingredient_categories_immutable_company
  before update on ingredient_categories
  for each row execute function private.prevent_company_id_change();

create trigger trg_ingredients_immutable_company
  before update on ingredients
  for each row execute function private.prevent_company_id_change();

create trigger trg_products_immutable_company
  before update on products
  for each row execute function private.prevent_company_id_change();

create trigger trg_inventory_counts_immutable_company
  before update on inventory_counts
  for each row execute function private.prevent_company_id_change();

-- Nota: company_users.company_id já é imutável desde a revisão 3, via
-- private.prevent_company_users_privilege_change() (20260815000006).
-- companies.id é a própria chave primária, não uma FK company_id, e PKs
-- não são alteradas pelo app.
