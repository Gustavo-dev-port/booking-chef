import type { MetadataRoute } from "next";

// PLACEHOLDER: nome, cores e ícones ainda não são a identidade visual final
// do produto — ajustar quando a marca/design system for definida (Fase 4+).
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Estoque & Ficha Técnica",
    short_name: "Estoque & Ficha",
    description:
      "Contagem de estoque e fichas técnicas com cálculo de custos para bares e restaurantes.",
    start_url: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#105c4b",
    lang: "pt-BR",
    icons: [
      {
        src: "/icons/icon-192.png",
        sizes: "192x192",
        type: "image/png",
      },
      {
        src: "/icons/icon-512.png",
        sizes: "512x512",
        type: "image/png",
      },
    ],
  };
}
