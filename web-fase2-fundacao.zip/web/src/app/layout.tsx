import type { Metadata, Viewport } from "next";
import "./globals.css";
import { QueryProvider } from "@/providers/query-provider";
import { ServiceWorkerRegister } from "@/components/layout/service-worker-register";

// Usamos a stack de fontes do sistema (via Tailwind) em vez de next/font/google
// nesta fase: evita depender de acesso à rede do Google Fonts no build e
// carrega mais rápido no celular. Uma fonte customizada pode ser adotada
// depois, junto com o design system (Fase 4+).

// PLACEHOLDER: título/descrição/ícones ainda usam a identidade provisória
// do produto (ver src/app/manifest.ts).
export const metadata: Metadata = {
  title: "Estoque & Ficha Técnica",
  description:
    "Contagem de estoque e fichas técnicas com cálculo de custos para bares e restaurantes.",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Estoque & Ficha",
  },
  icons: {
    apple: "/icons/apple-touch-icon.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#105c4b",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="pt-BR" className="h-full antialiased">
      <body className="min-h-full flex flex-col">
        <QueryProvider>{children}</QueryProvider>
        <ServiceWorkerRegister />
      </body>
    </html>
  );
}
