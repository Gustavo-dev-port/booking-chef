// PLACEHOLDER — Fase 2 (Fundação): ainda não há nenhuma funcionalidade de
// produto implementada. Onboarding, dashboard, insumos, fichas técnicas,
// contagem e histórico entram nas fases seguintes (ver web/docs/FASE1-ARQUITETURA.md).
export default function Home() {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-3 bg-zinc-50 px-6 text-center dark:bg-black">
      <p className="text-sm font-medium tracking-wide text-emerald-700 uppercase dark:text-emerald-400">
        Em construção — Fase 2: Fundação
      </p>
      <h1 className="max-w-md text-2xl font-semibold text-zinc-900 dark:text-zinc-50">
        Estoque &amp; Ficha Técnica
      </h1>
      <p className="max-w-sm text-sm text-zinc-600 dark:text-zinc-400">
        Base técnica do projeto (Next.js + Supabase) em construção. Nenhuma
        tela de produto foi implementada ainda.
      </p>
    </div>
  );
}
