import type { NextRequest } from "next/server";
import { updateSession } from "@/lib/supabase/proxy";

// Next.js 16 renomeou middleware.ts -> proxy.ts (mesma funcionalidade).
export async function proxy(request: NextRequest) {
  return updateSession(request);
}

export const config = {
  matcher: [
    /*
     * Roda em todas as rotas, exceto arquivos estáticos e de imagem —
     * ajustar a lista de exclusões conforme novas rotas públicas forem
     * criadas (ex.: página de login, termos, política de privacidade).
     */
    "/((?!_next/static|_next/image|favicon.ico|manifest.webmanifest|icons/|sw.js).*)",
  ],
};
