import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

/**
 * Atualiza a sessão do Supabase Auth a cada requisição (renovação de token
 * via cookies), chamado pelo proxy do Next.js (src/proxy.ts).
 *
 * Next.js 16 renomeou "middleware" para "proxy" — a lógica é a mesma do
 * padrão oficial do Supabase para Next.js, adaptada ao novo nome de arquivo.
 *
 * IMPORTANTE: isto só mantém a sessão viva entre requisições. Nunca é a
 * única proteção de uma rota — autenticação e autorização são sempre
 * reverificadas dentro de cada Server Action / Route Handler (ver
 * FASE1-ARQUITETURA.md, seção 9, e a "Data Security guide" do Next.js).
 */
export async function updateSession(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value),
          );
          supabaseResponse = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options),
          );
        },
      },
    },
  );

  // getClaims() valida o JWT localmente (sem round-trip à API do Supabase)
  // e força a renovação do token quando necessário. Não usamos o retorno
  // aqui para decidir autorização — isso é feito em cada rota/Server Action.
  await supabase.auth.getClaims();

  return supabaseResponse;
}
