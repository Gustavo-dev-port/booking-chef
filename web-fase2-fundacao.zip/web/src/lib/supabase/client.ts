import { createBrowserClient } from "@supabase/ssr";

/**
 * Cliente Supabase para uso em Client Components ("use client").
 *
 * Usa apenas a URL pública e a publishable key — protegido pelo Row Level
 * Security do Postgres, nunca por lógica no navegador (ver FASE1-ARQUITETURA.md, seção 9).
 */
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
  );
}
