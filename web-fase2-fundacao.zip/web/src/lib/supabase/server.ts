import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

/**
 * Cliente Supabase para uso em Server Components, Server Actions e Route
 * Handlers. Lê/escreve a sessão via cookies (padrão @supabase/ssr).
 *
 * Server Components não podem escrever cookies durante a renderização — se
 * `setAll` for chamado nesse contexto, o erro é ignorado silenciosamente
 * porque a sessão já terá sido atualizada pelo proxy (ver src/proxy.ts).
 */
export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options),
            );
          } catch {
            // Chamado a partir de um Server Component durante a renderização.
            // Pode ser ignorado se a sessão já for atualizada pelo proxy.
          }
        },
      },
    },
  );
}
