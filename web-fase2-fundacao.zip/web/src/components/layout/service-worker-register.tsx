"use client";

import { useEffect } from "react";

/**
 * Registra o service worker mínimo (public/sw.js) no client. Não tem UI —
 * só o efeito colateral necessário para o app ser instalável como PWA.
 */
export function ServiceWorkerRegister() {
  useEffect(() => {
    if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
      return;
    }
    navigator.serviceWorker.register("/sw.js").catch(() => {
      // Falha ao registrar não deve quebrar o app — PWA é progressive enhancement.
    });
  }, []);

  return null;
}
