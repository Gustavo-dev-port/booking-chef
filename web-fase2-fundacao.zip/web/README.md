# Estoque & Ficha Técnica — Web (PWA)

App Next.js + Supabase para contagem de estoque e fichas técnicas de bares e restaurantes. Ver o documento de arquitetura completo em [`docs/FASE1-ARQUITETURA.md`](./docs/FASE1-ARQUITETURA.md).

> Este projeto é independente do app Android em `../app` (protótipo separado gerado via Google AI Studio) — os dois convivem na mesma pasta do repositório, mas não compartilham código.

## Status

**Fase 2 — Fundação, em andamento.** Ainda não há nenhuma funcionalidade de produto implementada (onboarding, dashboard, insumos, fichas técnicas, contagem e histórico entram nas fases seguintes).

## Stack

Next.js (App Router) · TypeScript · Tailwind CSS · Supabase (Postgres + Auth via `@supabase/ssr` + Row Level Security) · TanStack Query · React Hook Form + Zod · Zustand.

## Como rodar localmente

```bash
npm install
cp .env.example .env.local   # preencha com os dados do seu projeto Supabase
npm run dev
```

Scripts disponíveis:

| Script | O que faz |
|---|---|
| `npm run dev` | Servidor de desenvolvimento |
| `npm run build` | Build de produção |
| `npm run start` | Roda o build de produção |
| `npm run lint` | ESLint |
| `npm run typecheck` | Checagem de tipos (`tsc --noEmit`) |

## Banco de dados

As migrations SQL e o teste de isolamento entre empresas (obrigatório antes de avançar da Fundação) estão em [`supabase/`](./supabase/README.md).

## Estrutura de pastas

Ver seção 6 de [`docs/FASE1-ARQUITETURA.md`](./docs/FASE1-ARQUITETURA.md). Resumo:

```
src/
  app/          rotas (App Router)
  components/   componentes de UI genéricos/reutilizáveis
  features/     lógica por domínio (auth, companies, ingredients, products, inventory, admin)
  lib/          clientes Supabase (browser/server via @supabase/ssr), helpers gerais
  services/     camada de acesso a dados por domínio (Data Access Layer)
  hooks, types, utils, validators, providers, config
```
